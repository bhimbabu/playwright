import { test, expect } from '@playwright/test';

test.only('API POST', async ({ request }) => {
  const response = await request.post('https://reqres.in/api/users', {
    headers: {
      'Content-Type': 'application/json'
    },
    json: {
      name: 'bhim',
      job: 'teacher'
    }
  });

  console.log('Status:', response.status());
  const body = await response.json();
  console.log('Response:', body);

  expect(response.status()).toBe(201);
});
