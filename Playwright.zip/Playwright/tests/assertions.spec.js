import { test, expect } from '@playwright/test'; 


test('Test Assertions', async ({ page }) => {
  await page.goto('https://kitchen.applitools.com/');
  await page.pause();
 
//Check element Present/Not present
await expect(page.locator('text=The Kitchen')).toHaveCount(1);
await page.$('text=The Kitchen')


//Check element Visible/Hidden
await expect(page.locator('text=The Kitchen')).toBeVisible()
await expect(page.locator('text=The Kitchen')).toBeHidden()

//Check element  Enabled/Disabled
await expect(page.locator('text=The Kitchen')).toBeEnabled()
await expect(page.locator('text=The Kitchen')).toBeDisabled()

//How to add Soft Assertions
await expect.soft(page.locator('text=The Kitchen')).toHaveText('XYZ')

//Check element Text matches value or not
await expect(page.locator('text=The Kitchen')).toHaveText('The Kitchen');
await expect(page.locator('text=The Kitchen')).not.toHaveText('ABCD');
await expect(page).toHaveScreenshot();
  
});