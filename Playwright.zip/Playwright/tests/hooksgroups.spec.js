import { test, expect } from '@playwright/test';

test('Hooks & Groups Test', async ({ page }) => {
  await page.goto('https://www.saucedemo.com/');
  await page.pause();

});