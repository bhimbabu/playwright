// tests/myfirsttest.spec.js

const {test, expect } = require('@playwright/test');

test('First Test', async ({ page }) => {
  await page.goto('https://google.com');
  await expect(page).toHaveTitle('Google');
});
