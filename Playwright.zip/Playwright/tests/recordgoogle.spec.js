import { test, expect } from '@playwright/test';

test('Google Page Test', async ({ page }) => {
  await page.goto('https://www.google.com/');
  await page.getByRole('combobox', { name: 'खोज्नुहोस्' }).click();
  await page.getByRole('combobox', { name: 'खोज्नुहोस्' }).click();
  await page.getByRole('combobox', { name: 'खोज्नुहोस्' }).fill('hello');
  await page.goto('https://www.google.com/');
  await page.locator('.lnXdpd').click();
  await page.getByRole('link', { name: 'फोटोहरू खोज्नुहोस्' }).click();
  await page.goto('https://www.google.com/');
});