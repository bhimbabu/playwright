import { test, expect } from '@playwright/test'; 

test('Selector Title', async ({ page }) => {
  await page.goto('https://www.saucedemo.com/');
  await page.fill('[data-test="username"]', 'standard_user');
  await page.fill('//input[@id="password"]', 'secret_sauce');

  // Click the login button
  await page.click('[data-test="login-button"]');
  // Wait for the inventory page to load and check the URL
  await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html');
  await page.waitForTimeout(7000);
});