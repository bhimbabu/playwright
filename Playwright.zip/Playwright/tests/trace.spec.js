// tests/trace-example.spec.js
const { test } = require('@playwright/test');

test('trace demo', async ({ page, context }) => {
  // Start tracing
  await context.tracing.start({ 
    screenshots: true, 
    snapshots: true 
  });

  await page.goto('https://google.com');
  await page.click('text=More information'); // if such element exists

  // Stop tracing and save to a ZIP file
  await context.tracing.stop({ path: 'trace.zip' });
});
